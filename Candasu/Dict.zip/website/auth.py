from logging import exception
from exceptiongroup import catch
from flask import Blueprint ,render_template,request,redirect,url_for,flash,session

import tensorflow as tf
from  keras.models import load_model
import copy
from sys import exit
import numpy as np 
from functools import wraps
from datetime import datetime
import pickle
# from tensorflow.keras import load_model
import tensorflow 
# from tensorflow import * 
# from tensorflow.keras import * 
# from p import Module1,Module2,Module3,Module2_instance,Module1_instance,Module3_instance 
import p
aut=Blueprint("auth",__name__)

@aut.route('/')
def home():
 return render_template('home.html')

@aut.route('/chandasu',methods=['GET','POST'])
def chandasu():
    try:
        if request.method == 'POST':
            print("hello")
            inp=request.form.get('cpoem')
            print(inp)
            # ex=open("ex1.txt",'w', encoding="utf8")
            with open('ex1.txt', 'w',encoding='utf-8') as ex:
                print("ex opened")
                for line in inp.split('\n'):
                    ex.write(line )
                    print(line)
            print("ex  opened for reading")
            f = open("ex1.txt","r",encoding="utf-8")
            print("after ex")
            f1=open("Chandassu.txt",'w', encoding="utf8")
            f1.close()
            f2=open("laghu_Guru.txt",'w', encoding="utf8")
            f2.close()
            print("after files")
            Module1_instance=p.Module1()
            akshara_list=Module1_instance.line_partition(f)
            Module2_instance=p.Module2()
            lm,lg_list=Module2_instance.laghu_guru(copy.deepcopy(akshara_list))
            Module3_instance=p.Module3()
            Module3_instance.chandassu(copy.deepcopy(akshara_list),copy.deepcopy(lg_list),copy.deepcopy(lm))
            with open('Chandassu.txt', 'r',encoding='utf8') as f5:
                content = f5.read()
                return render_template("chandasu.html",content=content)    

        return render_template("chandasu.html")    
    except Exception as e:
        flash(f"Something went wrong ,please logout and try again {e}",category="error")
        return render_template("home.html")    
    
def predict_output_for_sentence(sentence):
    print(type(sentence))
    # sentence = sentence.strip().split()
    tokenizer = tf.keras.preprocessing.text.Tokenizer()
    model1 = load_model('model.h5') 
    max_seq_length=8
    poem=sentence.strip().split()
    i=0
    while(i<len(poem)):
        # print(poem[i],len(poem[i]))
        if(len(poem[i])<=2 and i+1<len(poem)):
            poem[i+1]=poem[i]+poem[i+1]
            poem.remove(poem[i])
        else:
            i+=1
    ans = ""
    for i in poem:
        input_sequence = tokenizer.texts_to_sequences([i])
        input_sequence_padded = tf.keras.preprocessing.sequence.pad_sequences(input_sequence, maxlen=max_seq_length, padding='post')

        # Predict
        predicted_output_sequence = model1.predict(input_sequence_padded)[0]
        predicted_word_indices = np.argmax(predicted_output_sequence, axis=-1)

        # Convert predicted word indices to words
        predicted_words = tokenizer.sequences_to_texts([predicted_word_indices])[0].strip()
        # print('inside')
        # print(predicted_words)
        if(predicted_words==""):
            ans+=i+" "
        else:
            ans+=predicted_words+" "

        
    return ans

def get_word_meaning(word):
    # Implement your logic to get the meaning of the word from your meanings dictionary
    # This is a placeholder, you should replace it with your actual logic
    hash_key = word
    with open('hash_table.pkl', 'rb') as f:
                meanings = pickle.load(f)

                # print("Meanings")
                # print(meanings)
                try:
                    # print('fetching meaning')
                    # print(hash_key)
                    # print(meanings[hash_key])
                    if meanings[hash_key]=='' or meanings[hash_key]==None:
                        return word
                    return meanings[hash_key]
                except Exception as e:
                    # print(e)
                    pass

 
@aut.route('/translation',methods=['GET','POST'])
def translation():
    try:
        if request.method == 'POST':
            
            
            print("translation")
            inp2=request.form.get('tpoem')

            # print(type(inp2))
            # words = inp2.split('\n')
            # print(words)
            # print(words)
        # Process each word
            # processed_words = []
            # for word in words:
            #     # Predict the number of words for the current word
            #     processed_words.append(predict_word(word))
            #     # print(word)
            processed_words=predict_output_for_sentence(inp2)

            # Get the meaning of the word from the pickle file
            print("Printing proccesed words")
            print(processed_words)
            processed_words = processed_words.split()
            
            final=[]
            for i in range(len(processed_words)):
                print(processed_words[i])
                meaning = get_word_meaning(processed_words[i])
                # print(meaning)
                if meaning==None:
                    final.append(processed_words[i])
                final.append(meaning)
                print(final)

            print("Printing proccesed poem")
            final = [item for item in final if item is not None]
            print(final)
            # Join the processed words back into a poem
            processed_poem = ' '.join(final)
            # processed_poem=processed_words
            print(processed_poem)
            word_list = processed_poem.split()
            part_length = len(word_list) // 4

            # Create four lines
            line1 = " ".join(word_list[:part_length])
            line2 = " ".join(word_list[part_length:2 * part_length])
            line3 = " ".join(word_list[2 * part_length:3 * part_length])
            line4 = " ".join(word_list[3 * part_length:])

            # Write the lines to a text file
            with open("finalout.txt", "w", encoding="utf-8") as file:
                
                file.write(line1 + "\n")
                file.write(line2 + "\n")
                file.write(line3 + "\n")
                file.write(line4 + "\n")
            with open("finalout.txt", "r", encoding="utf-8") as file:
                processed_poem=file.read()
                return render_template('translation.html', content=processed_poem)

        return render_template('translation.html')
       
    except Exception as e:
        flash(f"Something went wrong {e}",category="error")
        return render_template("home.html")    
      